import cv2
import time
from face_recognition import face_main
from gait_recognition import gait_recognition
from motion_detection import motion_detection


def judgement(result1, result2):
    flag = False
    if result2[0] != '不认识':
        for i in result1:
            if i[0] == result2[0] and i[1] < 2:
                flag = True
    if flag:
        print('亮绿灯')
    else:
        print('亮红灯，发出蜂鸣声')


def main():
    # 步态识别摄像头
    cap1 = cv2.VideoCapture(1)
    cap1.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
    cap1.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

    fps = 30  # 帧率
    pre_frame = None
    while True:
        frames = []
        start = time.time()
        # 读取摄像头的帧
        ret, frame = cap1.read()
        if ret != True:
            break
        end = time.time()

        seconds = end - start

        if seconds < 1.0 / fps:
            time.sleep(1.0 / fps - seconds)

        # 在窗口中显示当前帧
        cv2.imshow("frame", frame)
        pre_frame, flag = motion_detection(pre_frame, frame)
        if flag:
            start = time.time()
            # 读取摄像头的帧
            ret, frame = cap1.read()
            if ret != True:
                break
            end = time.time()
            seconds = end - start
            if seconds < 1.0 / fps:
                time.sleep(1.0 / fps - seconds)
            while True:
                ret, frame = cap1.read()
                frames.append(frame)
                if len(frames) == 100:
                    break
        else:
            # 如果没有检测到人体，则重置开始时间
            print('.', end='')

        if frames:
            result1 = gait_recognition(frames)
            result2 = face_main()
            judgement(result1, result2)

        # 按下 'q' 键退出程序
        if cv2.waitKey(1) == ord('q'):
            break


if __name__ == '__main__':
    main()
