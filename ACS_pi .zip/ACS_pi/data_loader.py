import os
import cv2
import torch
import xarray as xr
import numpy as np
import os.path as osp
import torch.autograd as autograd

resolution = 64
cut_padding = int(float(resolution) / 64 * 10)


def ts2var(x):
    return autograd.Variable(x)


def np2var(x):
    return ts2var(torch.from_numpy(x))


def load_data(path):
    imgs = sorted(list(os.listdir(path)))
    frame_list = [np.reshape(
        cv2.imread(osp.join(path, _img_path)),
        [resolution, resolution, -1])[:, :, 0]
                  for _img_path in imgs
                  if osp.isfile(osp.join(path, _img_path))]
    num_list = list(range(len(frame_list)))
    data_dict = xr.DataArray(
        frame_list,
        coords={'frame': num_list},
        dims=['frame', 'img_y', 'img_x'],
    )
    data_dict = data_dict[:, :, cut_padding:-cut_padding].astype('float32') / 255.0
    data_dict_values = np2var(data_dict.values).float()
    x = data_dict_values.unsqueeze(0)
    return x

# model_path = "../work/checkpoint/GaitSet/GaitSet_CASIA-B_73_False_256_0.2_128_full_30-80000-encoder.ptm"
# encoder = SetNet(256).float().cuda()
# encoder = nn.DataParallel(encoder)
# encoder.load_state_dict(torch.load(model_path))
# encoder.eval()
#
# input_path = 'E://Microstar/python/GaitSet/pre_data/kpc_test/cl-02/090'
# feature1, _ = encoder(get_input(input_path))
# feature1 = feature1.cpu()
#
#
# with h5py.File('feature.h5', 'r') as f:
#     # 获取 HDF5 文件中所有数据集的名称
#     labels = list(f.keys())
#     n = len(labels)
#
#     # 逐个读取每个数据集并将其转换为 PyTorch 张量
#     tensors = []
#     for label in labels:
#         tensor_np = f[label][()]  # 从 HDF5 文件中读取数据集并将其转换为 NumPy 数组
#         tensor = torch.from_numpy(tensor_np)  # 将 NumPy 数组转换为 PyTorch 张量
#         tensors.append(tensor)  # 将张量存储到列表中
#
# distances = []
# for feature2 in tensors:
#     distance = F.pairwise_distance(feature1, feature2, p=2).mean().item()
#     distances.append(distance)
#
# target_list = [(label, distance) for label, distance in zip(labels, distances)]
# target_list.sort(key=lambda x: x[1])
#
# print(target_list)
# print(target_list[0])
