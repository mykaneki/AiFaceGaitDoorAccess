import os
import cv2
from PIL import Image
import numpy as np
import time

last_read_time = None


def create_new_dir():
    # 创建新目录
    if not os.path.exists('./data/saveimg'):
        os.makedirs('./data/saveimg')
    else:
        # 如果目录存在，清空目录中的文件
        files = os.listdir('./data/saveimg')
        for file in files:
            os.remove(os.path.join('./data/saveimg', file))


def save_image(img, count):
    img_path = './data/saveimg/{}.jpg'.format(count)
    cv2.imwrite(img_path, img)


def capture_images():
    # 调用摄像头实时识别人脸，并截取10张图片
    face_detector = cv2.CascadeClassifier('./haarcascade_frontalface_default.xml')
    cap = cv2.VideoCapture(0)
    count = 0
    while count < 10:
        ret, frame = cap.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_detector.detectMultiScale(gray)
        for x, y, w, h in faces:
            cv2.rectangle(frame, (x, y), (x + w, y + h), color=(0, 0, 255), thickness=2)
            cv2.circle(frame, center=(x + w // 2, y + h // 2), radius=w // 2, color=(0, 255, 0), thickness=1)
            save_image(frame[y:y + h, x:x + w], count + 1)
            count += 1
        cv2.imshow('capture', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()


def getImageAndLabels(path):
    facesSamples = []
    ids = []
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
    face_detector = cv2.CascadeClassifier('./haarcascade_frontalface_default.xml')
    for imagePath in imagePaths:
        PIL_img = Image.open(imagePath).convert('L')
        img_numpy = np.array(PIL_img, 'uint8')
        faces = face_detector.detectMultiScale(img_numpy)
        id = int(os.path.split(imagePath)[1].split('.')[0])
        for x, y, w, h in faces:
            ids.append(id)
            facesSamples.append(img_numpy[y:y + h, x:x + w])
    return facesSamples, ids


def check_new_images(path):
    global last_read_time
    new_images_detected = False
    for dirpath, dirnames, filenames in os.walk(path):
        for filename in filenames:
            creation_time = os.path.getctime(os.path.join(dirpath, filename))
            if last_read_time is None or creation_time > last_read_time:
                new_images_detected = True
                break
    if new_images_detected:
        last_read_time = time.time()
        train_recognizer('./data/img')


def train_recognizer(path):
    # 将所有人脸图片所提取的特征存储在trainer/savetrainer.yml
    facesSamples, ids = getImageAndLabels(path)
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.train(facesSamples, np.array(ids))
    recognizer.write('./trainer/savetrainer.yml')


def face_recognition(img_path):
    # 加载训练好的模型，并将截取的图片和图片库里的图片进行匹配
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read('./trainer/savetrainer.yml')
    img = cv2.imread(img_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face_detector = cv2.CascadeClassifier('./haarcascade_frontalface_default.xml')
    faces = face_detector.detectMultiScale(gray)
    for x, y, w, h in faces:
        cv2.rectangle(img, (x, y), (x + w, y + h), color=(0, 0, 255), thickness=2)
        cv2.circle(img, center=(x + w // 2, y + h // 2), radius=w // 2, color=(0, 255, 0), thickness=1)
        id_, confidence = recognizer.predict(gray[y:y + h, x:x + w])
        if confidence < 100:
            label = str(id_)
            confidence = "  {0}%".format(round(100 - confidence))
        else:
            label = "不认识"
            confidence = "  {0}%".format(round(100 - confidence))
        return label, confidence
        print("label: {},confidence: {}".format(label, confidence))
        img_name = '{}.jpg'.format(label)
        img_path = './data/img/{}'.format(img_name)
        if os.path.exists(img_path):
            img = cv2.imread(img_path)
        cv2.imshow('match result', img)
        cv2.waitKey(0)
        break
        cv2.imshow('result', img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()


def face_main():
    create_new_dir()
    capture_images()
    check_new_images('./data/img')
    return face_recognition('./data/saveimg/1.jpg')


if __name__ == '__main__':
    label, confidence = face_main
    print("label: {},confidence: {}".format(label, confidence))
