import os
import cv2
import torch
import numpy as np

from data_loader import load_data
from model.network import SetNet
import pretreatment as pre
import mysql.connector
from mysql.connector import Error


def video2img(video_path, output_path_root):
    if not os.path.exists(output_path_root):
        os.makedirs(output_path_root)
    # 打开要剪裁的视频文件
    cap = cv2.VideoCapture(video_path)

    # 检查视频是否成功打开
    if not cap.isOpened():
        print('无法打开视频文件')

    # 将图片调整为320x240
    new_size = (320, 240)

    # 循环遍历视频的每一帧
    frame_count = 0
    while True:
        # 读取下一帧
        ret, frame = cap.read()

        # 检查是否读取到了帧
        if not ret:
            print('没有读取到帧')
            break

        # 调整图片大小为320x240
        frame = cv2.resize(frame, new_size)

        # 在这里进行图像处理

        # 将帧转换为灰度图像
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # 使用OTSU算法将灰度图像转换为二值图像
        ret, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # 使用形态学操作填充人物区域
        kernel = np.ones((3, 3), np.uint8)
        closing = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=3)

        # 将人物区域的像素值设为黑色，背景区域的像素值设为白色
        result = np.zeros_like(frame)
        result[closing == 0] = (255, 255, 255)

        # 将当前帧保存为图片文件
        frame_count += 1
        file_name = f'{frame_count:03d}.jpg'
        path = output_path_root + '/' + file_name
        cv2.imwrite(path, result)

        # 如果所有帧都已经处理完毕，退出循环
        if frame_count == cap.get(cv2.CAP_PROP_FRAME_COUNT):
            break

    # 释放VideoCapture对象
    cap.release()

    # 关闭所有窗口
    cv2.destroyAllWindows()


def main(id, video_path):
    output_path_root = f'/home/pi/ACS_pi/store/raw_data/{id}/{id}/nm-01/090'
    video2img(video_path, output_path_root)
    pre.main(f'/home/pi/ACS_pi/store/raw_data/{id}', '/home/pi/ACS_pi/store/pre_data')
    model_path = "./work/checkpoint/GaitSet/GaitSet_CASIA-B_73_False_256_0.2_128_full_30-80000-encoder.ptm"
    encoder = SetNet(256).float()
    checkpoint = torch.load(model_path, map_location='cpu')
    encoder.load_state_dict(checkpoint, False)
    encoder.eval()

    # database
    file_path = f'/home/pi/ACS_pi/store/pre_data/{id}/nm-01/090'
    feature, _ = encoder(load_data(file_path))
    feature_data = feature.detach().numpy().tobytes()
    # 将特征数据插入到 MySQL 的 pure_admin 数据库的 users_img_info 表中
    insert_feature_data(id, feature_data)


def insert_feature_data(id, video_data):
    try:
        # 连接到数据库，使用自己的数据库凭据替换以下内容
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="passwd",
            database="pure_admin",
            port=3306
        )

        if connection.is_connected():
            cursor = connection.cursor(prepared=True)
            # 将 video_data 插入到表中
            # UPDATE runoob_tbl SET runoob_title='学习 C++' WHERE runoob_id=3;

            update_query = """UPDATE users_img_info SET video_data = %s WHERE id = %s"""
            print(update_query)
            cursor.execute(update_query, (video_data, id))

            # 提交更改并关闭连接
            connection.commit()
            print("Feature data inserted successfully")

    except Error as e:
        print("Error while connecting to MySQL", e)

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")


def fetch_feature_data():
    try:
        # 连接到数据库，使用自己的数据库凭据替换以下内容
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="passwd",
            database="pure_admin",
            port=3306
        )

        if connection.is_connected():
            cursor = connection.cursor()
            # 从 pure_admin 表中查询所有特征数据
            select_query = "SELECT id,video_data FROM users_img_info"
            cursor.execute(select_query)

            # 获取查询结果
            records = cursor.fetchall()

            # 将字节序列转换回 numpy.ndarray 并调整形状
            id_feature = {}
            for record in records:

                id_feature[record[0]] = torch.from_numpy(np.frombuffer(record[1], dtype=np.float32).reshape((1, 62, 256)))

            return id_feature

    except Error as e:
        print("Error while connecting to MySQL", e)

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")


if __name__ == '__main__':
    id = 10008
    video_path = '/home/pi/ACS_pi/data/cmy_data.mp4'
    main(id, video_path)
    # 获取数据库中存储的特征数据并转换回 numpy.ndarray
    # id_feature = fetch_feature_data()
    # print(id_feature.items())
