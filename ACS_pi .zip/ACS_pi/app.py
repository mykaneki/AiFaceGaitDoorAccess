from flask import Flask, request, jsonify

from store_api import main

# 其他导入...

# 在这里包含您提供的函数（video2img，ts2var，np2var，get_input 和 main）

app = Flask(__name__)


@app.route('/api/process_video', methods=['POST'])
def process_video():
    id = request.form.get('id')
    video_path = request.form.get('video')
    # print(id,video_path)

    if id is None or video_path is None:
        return jsonify({'error': 'ID and video_path are required'}), 400

    try:
        main(id, video_path)
        return jsonify({'ok': id}), 200
    except Exception as e:
        print(e)
        return jsonify({'error': 'Error processing video'}), 500


if __name__ == '__main__':
    app.run(port=5000, debug=True)
