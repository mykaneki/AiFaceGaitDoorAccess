import os
import cv2
import time
import numpy as np
import torch
import torch.nn.functional as F
import pretreatment as pre
from model.network import SetNet
from data_loader import load_data
from store_api import fetch_feature_data
from motion_detection import motion_detection


def frame_preprocess(frames):
    frame_count = 0
    now_time = int(time.time())
    for frame in frames:
        # 将帧转换为灰度图像
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # 使用OTSU算法将灰度图像转换为二值图像
        _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # 使用形态学操作填充人物区域
        kernel = np.ones((3, 3), np.uint8)
        closing = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=3)

        # 将人物区域的像素值设为黑色，背景区域的像素值设为白色
        result = np.zeros_like(frame)
        result[closing == 0] = (255, 255, 255)

        # 将当前帧保存为图片文件
        frame_count += 1
        file_name = f'{frame_count:03d}.jpg'
        file = f'/home/pi/ACS_pi/predict/raw_data/{now_time}/{now_time}/nm-01/090/'
        if not os.path.exists(file):
            os.makedirs(file)
            print('file created!')
        path = f'/home/pi/ACS_pi/predict/raw_data/{now_time}/{now_time}/nm-01/090/' + file_name
        cv2.imwrite(path, result)
    return now_time


def gait_recognition(frames):
    print('步态视频已截取，正在处理中。。。')
    id = frame_preprocess(frames)
    print('将视频转为帧，并处理为轮廓图，完成！')
    pre.main(f'/home/pi/ACS_pi/predict/raw_data/{id}',
             '/home/pi/ACS_pi/predict/pre_data')
    print('数据预处理已完成！')
    print('模型加载中，请稍后。。。')
    model_path = "./work/checkpoint/GaitSet/GaitSet_CASIA-B_73_False_256_0.2_128_full_30-80000-encoder.ptm"
    encoder = SetNet(256).float()
    # encoder = nn.DataParallel(encoder)
    checkpoint = torch.load(model_path, map_location='cpu')
    # state_dict = checkpoint['state_dict']
    encoder.load_state_dict(checkpoint, False)
    encoder.eval()
    print('模型加载已完成！')
    print('计算当前步态特征，请稍后。。。')
    file_path = f'/home/pi/ACS_pi/predict/pre_data/{id}/nm-01/090'
    feature1, _ = encoder(load_data(file_path))
    feature1 = feature1
    print('当前步态特征计算已完成！')
    print('正在进行数据库比对，请稍后。。。')
    id_feature = fetch_feature_data()
    labels = []
    distances = []
    for label, feature2 in id_feature.items():
        labels.append(label)
        distances.append(F.pairwise_distance(feature1, feature2, p=2).mean().item())
    target_list = [(label, distance) for label, distance in zip(labels, distances)]
    target_list.sort(key=lambda x: x[1])
    print('比对完成！')
    # print(target_list)
    return target_list


def gait_main():
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

    fps = 30  # 帧率
    pre_frame = None
    while True:
        frames = []
        start = time.time()
        # 读取摄像头的帧
        ret, frame = cap.read()
        if ret != True:
            break
        end = time.time()

        seconds = end - start

        if seconds < 1.0 / fps:
            time.sleep(1.0 / fps - seconds)

        # 在窗口中显示当前帧
        cv2.imshow("frame", frame)
        pre_frame, flag = motion_detection(pre_frame, frame)
        if flag:
            start = time.time()
            # 读取摄像头的帧
            ret, frame = cap.read()
            if ret != True:
                break
            end = time.time()
            seconds = end - start
            if seconds < 1.0 / fps:
                time.sleep(1.0 / fps - seconds)
            while True:
                ret, frame = cap.read()
                frames.append(frame)
                if len(frames) == 100:
                    break
        else:
            # 如果没有检测到人体，则重置开始时间
            print('未检测到物体！')

        if frames:
            result = gait_recognition(frames)
            return result

        # 按下 'q' 键退出程序
        if cv2.waitKey(1) == ord('q'):
            break


if __name__ == '__main__':
    gait_main()
